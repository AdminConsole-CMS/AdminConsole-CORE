<?php

/*
 * AdminConsole CORE is released under the GNU General Public License.
 * LICENSE.txt files in the main directory.
*/

/* AdminConsole CORE version */

$admin_console_version = "1.0.0";

?>