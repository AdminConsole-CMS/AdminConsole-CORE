<link rel="stylesheet" href="themes/default/style.css">
<script src="themes/default/js/jquery.min.js"></script>
<script src="themes/default/js/bootstrap.min.js"></script>